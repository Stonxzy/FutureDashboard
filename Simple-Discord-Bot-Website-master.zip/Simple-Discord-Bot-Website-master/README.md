# Simple discord bot website

<a href="https://discord.gg/2YQ2ydr">![Discord](https://img.shields.io/discord/692419586242641925.svg?logo=discord&colorB=7289DA)</a>