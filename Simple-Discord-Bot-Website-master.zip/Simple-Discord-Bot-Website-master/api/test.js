module.exports = {
    run: async function (req, res) {
        return res.status(200).send("NOICEEEEE")
    }
}